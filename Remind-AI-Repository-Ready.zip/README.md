# Remind AI — Premium Android starter

## Included
- Clean, Claude-inspired light UI with soft lavender gradients, glass-like cards, rounded surfaces and subtle entrance animations.
- English, Hindi, Bengali and Tamil interface language options.
- Font-size setting.
- Reminder create, edit, complete and delete.
- Search, categories, priority and optional notes.
- Local scheduled notifications and restore after device restart.
- Focus mode with a 25-minute timer.
- On-device storage. No login, backend, paid API or API key required.

## Build APK
1. Upload the **contents** of this folder to the root of `dropmotion551gpt/Remind-Ai-`.
2. Preserve the `.github/workflows/build.yml` path.
3. Commit to `main`.
4. Open **Actions → Build Remind AI APK**.
5. Download the `Remind-AI-APK` artifact and extract `Remind-AI.apk`.

The installed app label is `Remind AI`. APK output is a genuine build, not artificially padded to a target size.

## Honest limitations
The Smart Ideas panel uses local suggestion templates. It is not connected to a generative AI model. Cloud sync, accounts, voice dictation and cross-device reminders are not included in this starter build. Android battery optimization can delay inexact alarms; Android 13+ requires notification permission.
