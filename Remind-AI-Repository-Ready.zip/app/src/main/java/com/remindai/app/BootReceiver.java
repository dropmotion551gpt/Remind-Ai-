package com.remindai.app;

import android.app.*;
import android.content.*;
import java.util.List;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        List<Reminder> items = ReminderStore.load(context);
        for (Reminder r : items) {
            if (r.done || r.time <= System.currentTimeMillis()) continue;
            Intent alert = new Intent(context, ReminderReceiver.class).putExtra("title", r.title);
            PendingIntent pi = PendingIntent.getBroadcast(context, (int)r.id, alert,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.time, pi);
        }
    }
}
