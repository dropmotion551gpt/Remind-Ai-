package com.remindai.app;

import org.json.JSONObject;

public class Reminder {
    public long id, time;
    public String title, note, category, priority;
    public boolean done;

    public Reminder(long id, String title, String note, String category, String priority, long time, boolean done) {
        this.id=id; this.title=title; this.note=note; this.category=category;
        this.priority=priority; this.time=time; this.done=done;
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id); o.put("title", title); o.put("note", note);
            o.put("category", category); o.put("priority", priority);
            o.put("time", time); o.put("done", done);
        } catch (Exception ignored) {}
        return o;
    }

    public static Reminder fromJson(JSONObject o) {
        return new Reminder(o.optLong("id"), o.optString("title"), o.optString("note"),
            o.optString("category", "Personal"), o.optString("priority", "Normal"),
            o.optLong("time"), o.optBoolean("done", false));
    }
}
