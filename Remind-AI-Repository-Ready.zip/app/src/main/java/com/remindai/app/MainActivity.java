package com.remindai.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final ArrayList<Reminder> items = new ArrayList<>();
    private LinearLayout root, content, list;
    private EditText search;
    private String language = "English";
    private String activeCategory = "All";
    private int page = 0;
    private int fontScale = 0;
    private final int bg = Color.rgb(248,248,252), ink = Color.rgb(35,37,54);
    private final int muted = Color.rgb(132,135,153), violet = Color.rgb(104,105,220);
    private final int mint = Color.rgb(35,185,149), border = Color.rgb(235,235,243);

    private String tr(String key) {
        String[][] rows = {
            {"Home","Home","होम","হোম","முகப்பு"},
            {"Focus","Focus","फोकस","ফোকাস","கவனம்"},
            {"Settings","Settings","सेटिंग्स","সেটিংস","அமைப்புகள்"},
            {"Good morning","Good morning","सुप्रभात","সুপ্রভাত","காலை வணக்கம்"},
            {"Your day, gently organised.","Your day, gently organised.","आपका दिन, बेहतर तरीके से।","আপনার দিন, সুন্দরভাবে সাজানো।","உங்கள் நாள், ஒழுங்காக."},
            {"Create a reminder","Create a reminder","रिमाइंडर बनाएँ","রিমাইন্ডার তৈরি করুন","நினைவூட்டல் உருவாக்கு"},
            {"What would you like to remember?","What would you like to remember?","क्या याद रखना है?","কী মনে রাখতে চান?","எதை நினைவில் வைக்க வேண்டும்?"},
            {"Upcoming","Upcoming","आने वाले","আসন্ন","வரவிருப்பவை"},
            {"All","All","सभी","সব","அனைத்தும்"},
            {"Personal","Personal","व्यक्तिगत","ব্যক্তিগত","தனிப்பட்ட"},
            {"Work","Work","काम","কাজ","வேலை"},
            {"Study","Study","पढ़ाई","পড়াশোনা","படிப்பு"},
            {"Health","Health","स्वास्थ्य","স্বাস্থ্য","ஆரோக்கியம்"},
            {"No reminders yet","No reminders yet","अभी कोई रिमाइंडर नहीं","এখনও কোনো রিমাইন্ডার নেই","நினைவூட்டல்கள் இல்லை"},
            {"Add your first reminder and make space for what matters.","Add your first reminder and make space for what matters.","पहला रिमाइंडर जोड़ें और जरूरी कामों के लिए समय बनाएँ।","প্রথম রিমাইন্ডার যোগ করুন।","முதல் நினைவூட்டலைச் சேர்க்கவும்."},
            {"Smart ideas","Smart ideas","स्मार्ट सुझाव","স্মার্ট আইডিয়া","சிறந்த யோசனைகள்"},
            {"A little nudge for your day","A little nudge for your day","आपके दिन के लिए एक छोटा सुझाव","দিনের জন্য ছোট্ট পরামর্শ","உங்கள் நாளுக்கான சிறு நினைவூட்டல்"},
            {"Language","Language","भाषा","ভাষা","மொழி"},
            {"Font size","Font size","फ़ॉन्ट आकार","ফন্ট সাইজ","எழுத்து அளவு"},
            {"Notifications","Notifications","नोटिफिकेशन","বিজ্ঞপ্তি","அறிவிப்புகள்"},
            {"About Remind AI","About Remind AI","Remind AI के बारे में","Remind AI সম্পর্কে","Remind AI பற்றி"},
            {"Save reminder","Save reminder","रिमाइंडर सेव करें","রিমাইন্ডার সংরক্ষণ","நினைவூட்டலை சேமி"},
            {"Title","Title","शीर्षक","শিরোনাম","தலைப்பு"},
            {"Note (optional)","Note (optional)","नोट (वैकल्पिक)","নোট (ঐচ্ছিক)","குறிப்பு (விருப்பம்)"},
            {"Date & time","Date & time","तारीख और समय","তারিখ ও সময়","தேதி & நேரம்"},
            {"Priority","Priority","प्राथमिकता","অগ্রাধিকার","முன்னுரிமை"},
            {"Normal","Normal","सामान्य","সাধারণ","இயல்பு"},
            {"High","High","जरूरी","উচ্চ","அதிகம்"},
            {"Done","Done","पूरा","সম্পন্ন","முடிந்தது"},
            {"Delete","Delete","डिलीट","মুছুন","நீக்கு"},
            {"Edit","Edit","बदलें","সম্পাদনা","திருத்து"},
            {"Search reminders","Search reminders","रिमाइंडर खोजें","রিমাইন্ডার খুঁজুন","தேடுங்கள்"},
            {"Choose language","Choose language","भाषा चुनें","ভাষা নির্বাচন করুন","மொழியைத் தேர்ந்தெடுக்கவும்"},
            {"Choose font size","Choose font size","फ़ॉन्ट आकार चुनें","ফন্ট সাইজ নির্বাচন","எழுத்து அளவைத் தேர்ந்தெடுக்கவும்"},
            {"Small","Small","छोटा","ছোট","சிறியது"},
            {"Standard","Standard","सामान्य","সাধারণ","இயல்பு"},
            {"Large","Large","बड़ा","বড়","பெரியது"},
            {"No matches","No matches","कुछ नहीं मिला","কিছু পাওয়া যায়নি","எதுவும் இல்லை"},
            {"Focus mode","Focus mode","फोकस मोड","ফোকাস মোড","கவன முறை"},
            {"Keep one thing in front of you.","Keep one thing in front of you.","एक समय में एक काम पर ध्यान दें।","একবারে একটি কাজে মন দিন।","ஒரு வேலையில் கவனம் செலுத்துங்கள்."}
        };
        int col = language.equals("Hindi")?2:language.equals("Bengali")?3:language.equals("Tamil")?4:1;
        for (String[] row:rows) if (row[0].equals(key)) return row[col];
        return key;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= 23)
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        language = getPreferences(0).getString("language","English");
        fontScale = getPreferences(0).getInt("fontScale",0);
        items.addAll(ReminderStore.load(this));
        askNotificationPermission();
        showPage(0);
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 31);
    }

    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density+.5f); }
    private int fs(int n) { return n + (fontScale==1?-2:fontScale==2?3:0); }

    private GradientDrawable bgShape(int color,int radius,int stroke) {
        GradientDrawable d=new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke);
        return d;
    }

    private GradientDrawable gradient(int a,int b,int radius) {
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});
        d.setCornerRadius(dp(radius)); return d;
    }

    private TextView txt(String value,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(value); t.setTextSize(fs(size)); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        t.setIncludeFontPadding(true); return t;
    }

    private LinearLayout column() {
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }

    private LinearLayout row() {
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }

    private void pad(View v,int l,int t,int r,int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }

    private void showPage(int which) {
        page=which;
        root=column(); root.setBackgroundColor(bg);
        root.setPadding(dp(20),dp(14),dp(20),dp(8));
        LinearLayout header=row();
        TextView mark=txt("◷",27,Color.WHITE,true); mark.setGravity(Gravity.CENTER);
        mark.setBackground(gradient(violet,Color.rgb(139,130,235),18));
        header.addView(mark,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout brand=column(); brand.setPadding(dp(11),0,0,0);
        brand.addView(txt("Remind AI",20,ink,true));
        brand.addView(txt("A calmer way to stay on track",11,muted,false));
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView avatar=txt("✦",20,violet,true); avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(bgShape(Color.WHITE,18,border));
        header.addView(avatar,new LinearLayout.LayoutParams(dp(42),dp(42)));
        root.addView(header);

        content=column();
        LinearLayout.LayoutParams contentParams=new LinearLayout.LayoutParams(-1,0,1);
        contentParams.topMargin=dp(12);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        scroll.setClipToPadding(false); scroll.addView(content);
        root.addView(scroll,contentParams);

        LinearLayout nav=row(); nav.setBackground(bgShape(Color.WHITE,22,border)); nav.setElevation(dp(3));
        nav.setPadding(dp(5),dp(5),dp(5),dp(5));
        String[] names={tr("Home"),tr("Focus"),tr("Settings")};
        String[] icons={"⌂","◉","⚙"};
        for(int i=0;i<3;i++){
            final int target=i;
            LinearLayout item=column(); item.setGravity(Gravity.CENTER);
            TextView icon=txt(icons[i],19,i==which?violet:muted,true); icon.setGravity(Gravity.CENTER);
            TextView label=txt(names[i],10,i==which?violet:muted,i==which);
            item.addView(icon); item.addView(label);
            item.setBackground(i==which?bgShape(0xFFF0F0FF,16,0):bgShape(Color.TRANSPARENT,16,0));
            item.setOnClickListener(v->showPage(target));
            LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(52),1);
            nav.addView(item,np);
        }
        LinearLayout.LayoutParams navp=new LinearLayout.LayoutParams(-1,-2); navp.topMargin=dp(8); navp.bottomMargin=dp(4);
        root.addView(nav,navp);
        setContentView(root);
        root.setAlpha(0f); root.setTranslationY(dp(8));
        root.animate().alpha(1f).translationY(0).setDuration(240).setInterpolator(new DecelerateInterpolator()).start();

        if(which==0) buildHome();
        else if(which==1) buildFocus();
        else buildSettings();
    }

    private void buildHome() {
        Calendar now=Calendar.getInstance();
        int hour=now.get(Calendar.HOUR_OF_DAY);
        String greeting=hour<12?tr("Good morning"):hour<17?"Good afternoon":"Good evening";
        TextView hello=txt(greeting,26,ink,true);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); hp.topMargin=dp(16); content.addView(hello,hp);
        content.addView(txt(tr("Your day, gently organised."),14,muted,false));

        int pending=0; for(Reminder r:items) if(!r.done) pending++;
        LinearLayout hero=column(); hero.setPadding(dp(18),dp(18),dp(18),dp(18));
        hero.setBackground(gradient(Color.rgb(239,239,255),Color.rgb(248,242,255),24));
        hero.setElevation(dp(1));
        LinearLayout.LayoutParams herop=new LinearLayout.LayoutParams(-1,-2); herop.topMargin=dp(20); content.addView(hero,herop);
        LinearLayout hr=row();
        LinearLayout hleft=column(); hleft.addView(txt("TODAY'S SPACE",10,violet,true));
        hleft.addView(txt(pending+"",34,ink,true));
        hleft.addView(txt("reminders to keep in view",12,muted,false));
        hr.addView(hleft,new LinearLayout.LayoutParams(0,-2,1));
        TextView bubble=txt("✦",27,violet,true); bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(gradient(Color.WHITE,0xFFE8E7FF,50));
        hr.addView(bubble,new LinearLayout.LayoutParams(dp(66),dp(66))); hero.addView(hr);
        TextView date=txt(new SimpleDateFormat("EEEE, d MMMM",Locale.getDefault()).format(new Date()),12,muted,false);
        LinearLayout.LayoutParams datep=new LinearLayout.LayoutParams(-1,-2); datep.topMargin=dp(8); hero.addView(date,datep);

        LinearLayout create=row(); create.setPadding(dp(16),dp(15),dp(16),dp(15));
        create.setBackground(gradient(violet,Color.rgb(126,117,225),18));
        LinearLayout.LayoutParams crp=new LinearLayout.LayoutParams(-1,-2); crp.topMargin=dp(18); content.addView(create,crp);
        LinearLayout ctext=column(); ctext.addView(txt(tr("Create a reminder"),16,Color.WHITE,true));
        ctext.addView(txt("Capture it now. Relax later.",11,0xFFEAEAFF,false));
        create.addView(ctext,new LinearLayout.LayoutParams(0,-2,1));
        TextView plus=txt("＋",28,Color.WHITE,true); plus.setGravity(Gravity.CENTER); create.addView(plus);
        create.setOnClickListener(v->showReminderDialog(null));

        LinearLayout smart=row(); smart.setPadding(dp(14),dp(13),dp(14),dp(13));
        smart.setBackground(bgShape(Color.WHITE,18,border));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(12); content.addView(smart,sp);
        TextView sparkle=txt("✧",22,violet,true); smart.addView(sparkle);
        LinearLayout smartText=column(); smartText.setPadding(dp(10),0,0,0);
        smartText.addView(txt(tr("Smart ideas"),14,ink,true)); smartText.addView(txt(tr("A little nudge for your day"),11,muted,false));
        smart.addView(smartText,new LinearLayout.LayoutParams(0,-2,1));
        smart.addView(txt("›",24,muted,false));
        smart.setOnClickListener(v->showIdeas());

        TextView upcoming=txt(tr("Upcoming"),18,ink,true);
        LinearLayout.LayoutParams up=new LinearLayout.LayoutParams(-1,-2); up.topMargin=dp(22); content.addView(upcoming,up);
        search=new EditText(this); search.setSingleLine(true); search.setTextSize(fs(13)); search.setHint(tr("Search reminders"));
        search.setTextColor(ink); search.setHintTextColor(muted); search.setPadding(dp(14),0,dp(14),0);
        search.setBackground(bgShape(Color.WHITE,14,border));
        LinearLayout.LayoutParams srp=new LinearLayout.LayoutParams(-1,dp(46)); srp.topMargin=dp(10); content.addView(search,srp);
        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){renderReminders();}
            public void afterTextChanged(android.text.Editable e){}
        });
        HorizontalScrollView cats=new HorizontalScrollView(this); cats.setHorizontalScrollBarEnabled(false);
        LinearLayout catrow=row(); catrow.setPadding(0,dp(10),0,dp(6));
        String[] categories={"All","Personal","Work","Study","Health"};
        for(String c:categories){
            TextView chip=txt(tr(c),12,activeCategory.equals(c)?Color.WHITE:muted,activeCategory.equals(c));
            pad(chip,14,9,14,9); chip.setBackground(bgShape(activeCategory.equals(c)?violet:Color.WHITE,30,activeCategory.equals(c)?0:border));
            LinearLayout.LayoutParams chipP=new LinearLayout.LayoutParams(-2,-2); chipP.rightMargin=dp(7); catrow.addView(chip,chipP);
            chip.setOnClickListener(v->{activeCategory=c; showPage(0);});
        }
        cats.addView(catrow); content.addView(cats);
        list=column(); content.addView(list); renderReminders();
    }

    private void renderReminders() {
        if(list==null)return;
        list.removeAllViews();
        ArrayList<Reminder> sorted=new ArrayList<>(items);
        sorted.sort((a,b)->Long.compare(a.time,b.time));
        String query=search==null?"":search.getText().toString().toLowerCase(Locale.ROOT);
        int count=0;
        for(Reminder r:sorted){
            if(r.done)continue;
            if(!activeCategory.equals("All")&&!r.category.equals(activeCategory))continue;
            if(!r.title.toLowerCase(Locale.ROOT).contains(query)&&!r.note.toLowerCase(Locale.ROOT).contains(query))continue;
            count++;
            LinearLayout card=column(); card.setPadding(dp(15),dp(13),dp(15),dp(12));
            card.setBackground(bgShape(Color.WHITE,18,border));
            card.setElevation(dp(1));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.bottomMargin=dp(9); list.addView(card,cp);
            LinearLayout top=row();
            TextView dot=txt(r.priority.equals("High")?"●":"○",13,r.priority.equals("High")?0xFFE79A54:mint,true);
            top.addView(dot);
            TextView title=txt(r.title,15,ink,true); title.setPadding(dp(8),0,0,0);
            top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
            TextView more=txt("•••",16,muted,true); top.addView(more);
            card.addView(top);
            if(!r.note.isEmpty()){
                TextView note=txt(r.note,12,muted,false); LinearLayout.LayoutParams n=new LinearLayout.LayoutParams(-1,-2); n.topMargin=dp(5); card.addView(note,n);
            }
            LinearLayout bottom=row(); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=dp(10); card.addView(bottom,bp);
            TextView when=txt(new SimpleDateFormat("EEE, d MMM · h:mm a",Locale.getDefault()).format(new Date(r.time)),11,muted,false);
            bottom.addView(when,new LinearLayout.LayoutParams(0,-2,1));
            TextView category=txt(r.category,10,violet,true); pad(category,9,5,9,5); category.setBackground(bgShape(0xFFF1F0FF,12,0)); bottom.addView(category);
            LinearLayout actions=row(); actions.setGravity(Gravity.END);
            TextView done=txt("✓  "+tr("Done"),11,mint,true); pad(done,10,7,10,7);
            TextView edit=txt(tr("Edit"),11,violet,true); pad(edit,10,7,10,7);
            TextView del=txt(tr("Delete"),11,muted,false); pad(del,10,7,10,7);
            actions.addView(done); actions.addView(edit); actions.addView(del);
            LinearLayout.LayoutParams actp=new LinearLayout.LayoutParams(-1,-2); actp.topMargin=dp(6); card.addView(actions,actp);
            done.setOnClickListener(v->{r.done=true; cancelAlarm(r); persist(); renderReminders();});
            edit.setOnClickListener(v->showReminderDialog(r));
            del.setOnClickListener(v->{new AlertDialog.Builder(this).setMessage("Delete this reminder?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{cancelAlarm(r);items.remove(r);persist();renderReminders();}).show();});
            card.setAlpha(0f); card.setTranslationY(dp(8));
            card.animate().alpha(1f).translationY(0).setDuration(220).start();
        }
        if(count==0){
            LinearLayout empty=column(); empty.setGravity(Gravity.CENTER); empty.setPadding(dp(16),dp(24),dp(16),dp(24));
            TextView icon=txt("✧",26,violet,true); icon.setGravity(Gravity.CENTER); empty.addView(icon);
            TextView title=txt(tr(query.isEmpty()? "No reminders yet":"No matches"),15,ink,true); title.setGravity(Gravity.CENTER); empty.addView(title);
            TextView desc=txt(tr("Add your first reminder and make space for what matters."),12,muted,false); desc.setGravity(Gravity.CENTER);
            empty.addView(desc); list.addView(empty);
        }
    }

    private void showReminderDialog(Reminder existing) {
        LinearLayout form=column(); form.setPadding(dp(4),dp(8),dp(4),0);
        EditText title=new EditText(this); title.setSingleLine(true); title.setHint(tr("Title")); title.setTextSize(15);
        title.setText(existing==null?"":existing.title); form.addView(title);
        EditText note=new EditText(this); note.setHint(tr("Note (optional)")); note.setTextSize(13);
        note.setText(existing==null?"":existing.note); form.addView(note);
        Spinner category=new Spinner(this);
        String[] cats={"Personal","Work","Study","Health"};
        category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats));
        if(existing!=null)for(int i=0;i<cats.length;i++)if(cats[i].equals(existing.category))category.setSelection(i);
        form.addView(category);
        Spinner priority=new Spinner(this);
        String[] priorities={"Normal","High"};
        priority.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,priorities));
        if(existing!=null&&"High".equals(existing.priority))priority.setSelection(1);
        form.addView(priority);
        final long[] chosen={existing==null?System.currentTimeMillis()+3600000L:existing.time};
        TextView date=txt("",13,violet,true); pad(date,10,12,10,12); date.setBackground(bgShape(0xFFF3F2FF,12,0));
        Runnable updateDate=()->date.setText("◷   "+new SimpleDateFormat("EEE, d MMM · h:mm a",Locale.getDefault()).format(new Date(chosen[0]))+"   ·   "+tr("Date & time"));
        updateDate.run(); date.setOnClickListener(v->{
            Calendar c=Calendar.getInstance();c.setTimeInMillis(chosen[0]);
            new DatePickerDialog(this,(view,y,m,d)->{
                Calendar x=Calendar.getInstance();x.setTimeInMillis(chosen[0]);x.set(y,m,d);
                new TimePickerDialog(this,(tv,h,min)->{x.set(Calendar.HOUR_OF_DAY,h);x.set(Calendar.MINUTE,min);x.set(Calendar.SECOND,0);chosen[0]=x.getTimeInMillis();updateDate.run();},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),false).show();
            },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
        });
        form.addView(date);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(existing==null?tr("Create a reminder"):tr("Edit"))
            .setView(form).setNegativeButton("Cancel",null).setPositiveButton(tr("Save reminder"),null).create();
        dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(view->{
            String t=title.getText().toString().trim();
            if(t.isEmpty()){title.setError(tr("Title"));return;}
            if(chosen[0]<=System.currentTimeMillis()){Toast.makeText(this,"Choose a future time",Toast.LENGTH_SHORT).show();return;}
            if(existing==null){
                Reminder r=new Reminder(System.currentTimeMillis(),t,note.getText().toString().trim(),cats[category.getSelectedItemPosition()],priorities[priority.getSelectedItemPosition()],chosen[0],false);
                items.add(r);schedule(r);
            }else{
                cancelAlarm(existing);existing.title=t;existing.note=note.getText().toString().trim();
                existing.category=cats[category.getSelectedItemPosition()];existing.priority=priorities[priority.getSelectedItemPosition()];
                existing.time=chosen[0];schedule(existing);
            }
            persist();dialog.dismiss();showPage(0);
        }));
        dialog.show();
    }

    private void schedule(Reminder r) {
        AlarmManager alarms=(AlarmManager)getSystemService(ALARM_SERVICE);
        Intent i=new Intent(this,ReminderReceiver.class).putExtra("title",r.title);
        PendingIntent pi=PendingIntent.getBroadcast(this,(int)r.id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,r.time,pi);
    }

    private void cancelAlarm(Reminder r) {
        Intent i=new Intent(this,ReminderReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(this,(int)r.id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pi);
    }

    private void persist(){ReminderStore.save(this,items);}

    private void showIdeas() {
        String[] ideas={"Drink a glass of water","Take a 10-minute movement break","Review today's top priority","Prepare tomorrow's to-do list"};
        new AlertDialog.Builder(this).setTitle(tr("Smart ideas"))
            .setItems(ideas,(d,which)->{
                String selected=ideas[which];
                Reminder r=new Reminder(System.currentTimeMillis(),selected,"Suggested by Remind AI","Personal","Normal",System.currentTimeMillis()+3600000L,false);
                items.add(r);persist();schedule(r);showPage(0);
            }).setNegativeButton("Close",null).show();
    }

    private void buildFocus() {
        TextView title=txt(tr("Focus mode"),25,ink,true);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(25);content.addView(title,tp);
        content.addView(txt(tr("Keep one thing in front of you."),14,muted,false));
        LinearLayout card=column();card.setGravity(Gravity.CENTER);card.setPadding(dp(22),dp(28),dp(22),dp(28));
        card.setBackground(gradient(0xFFF0EFFF,0xFFF9F4FF,26));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(25);content.addView(card,cp);
        TextView orb=txt("✦",42,violet,true);orb.setGravity(Gravity.CENTER);
        orb.setBackground(gradient(Color.WHITE,0xFFE8E6FF,80));card.addView(orb,new LinearLayout.LayoutParams(dp(100),dp(100)));
        TextView timer=txt("25:00",42,ink,true);timer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams t=new LinearLayout.LayoutParams(-1,-2);t.topMargin=dp(18);card.addView(timer,t);
        card.addView(txt("A quiet space for one meaningful task.",13,muted,false));
        final int[] seconds={1500};final boolean[] running={false};final Handler handler=new Handler();
        Button start=new Button(this);start.setText("Start focus");start.setAllCaps(false);start.setTextColor(Color.WHITE);start.setBackground(bgShape(violet,16,0));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(50));bp.topMargin=dp(18);card.addView(start,bp);
        Runnable tick=new Runnable(){public void run(){if(!running[0])return;if(seconds[0]>0){seconds[0]--;timer.setText(String.format(Locale.getDefault(),"%02d:%02d",seconds[0]/60,seconds[0]%60));handler.postDelayed(this,1000);}else{running[0]=false;start.setText("Start again");Toast.makeText(MainActivity.this,"Focus session complete",Toast.LENGTH_LONG).show();}}};
        start.setOnClickListener(v->{if(running[0]){running[0]=false;handler.removeCallbacks(tick);start.setText("Resume");}else{if(seconds[0]==0)seconds[0]=1500;running[0]=true;start.setText("Pause");handler.post(tick);}});
    }

    private void buildSettings() {
        TextView title=txt(tr("Settings"),26,ink,true);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(25);content.addView(title,tp);
        content.addView(txt("Make Remind AI feel like yours.",13,muted,false));
        settingRow("🌐",tr("Language"),language,"Choose language",()->{
            String[] langs={"English","Hindi","Bengali","Tamil"};
            new AlertDialog.Builder(this).setTitle(tr("Choose language")).setSingleChoiceItems(langs,Arrays.asList(langs).indexOf(language),(d,w)->{
                language=langs[w];getPreferences(0).edit().putString("language",language).apply();d.dismiss();showPage(2);
            }).setNegativeButton("Cancel",null).show();
        });
        settingRow("Aa",tr("Font size"),fontScale==0?tr("Standard"):fontScale==1?tr("Small"):tr("Large"),"Choose font size",()->{
            String[] sizes={tr("Standard"),tr("Large"),tr("Small")};
            new AlertDialog.Builder(this).setTitle(tr("Choose font size")).setItems(sizes,(d,w)->{
                fontScale=w==0?0:w==1?2:1;getPreferences(0).edit().putInt("fontScale",fontScale).apply();showPage(2);
            }).show();
        });
        settingRow("◉",tr("Notifications"),"Android notification permission","",()->askNotificationPermission());
        settingRow("✧",tr("About Remind AI"),"Version 1.1 · Offline-first","",()->new AlertDialog.Builder(this).setTitle("Remind AI").setMessage("A calm space to capture tasks, build routines and remember what matters. Your reminders stay on this device.").setPositiveButton("OK",null).show());
        TextView note=txt("Your reminders are stored locally on this phone. Cloud sync and connected generative AI are not enabled in this version.",12,muted,false);
        note.setPadding(dp(14),dp(16),dp(14),dp(16));note.setBackground(bgShape(Color.WHITE,16,border));
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(14);content.addView(note,np);
    }

    private void settingRow(String icon,String label,String value,String unused,Runnable action) {
        LinearLayout card=row();card.setPadding(dp(14),dp(14),dp(14),dp(14));card.setBackground(bgShape(Color.WHITE,17,border));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(12);content.addView(card,p);
        TextView ic=txt(icon,20,violet,true);ic.setGravity(Gravity.CENTER);card.addView(ic,new LinearLayout.LayoutParams(dp(34),dp(34)));
        LinearLayout texts=column();texts.setPadding(dp(10),0,0,0);texts.addView(txt(label,14,ink,true));texts.addView(txt(value,11,muted,false));
        card.addView(texts,new LinearLayout.LayoutParams(0,-2,1));card.addView(txt("›",22,muted,false));
        card.setOnClickListener(v->action.run());
    }
}
