package com.remindai.app;

import android.content.Context;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.List;

public final class ReminderStore {
    private static final String PREFS="remind_ai_data", KEY="reminders";
    private ReminderStore() {}

    public static List<Reminder> load(Context c) {
        List<Reminder> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(PREFS,0).getString(KEY,"[]"));
            for (int i=0;i<a.length();i++) out.add(Reminder.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {}
        return out;
    }

    public static void save(Context c, List<Reminder> items) {
        JSONArray a = new JSONArray();
        for (Reminder r:items) a.put(r.toJson());
        c.getSharedPreferences(PREFS,0).edit().putString(KEY,a.toString()).apply();
    }
}
